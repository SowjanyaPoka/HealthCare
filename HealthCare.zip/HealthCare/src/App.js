import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Home from './Home';
import SignUp from './SignUp';
import NavBar from './NavBar';
import Doctors from './Doctors';
import PharmaDetails from './PharmaDetails';
import './App.css';
const App = () => {
  return (
    <Router>
      <div>
        <NavBar />
        <Switch>
          <Route exact path="/">
            <Home />
          </Route>
          <Route path="/doctorsList">
            <Doctors />
          </Route>
          <Route path="/pharmaciesdetails">
            <PharmaDetails />
          </Route>
          <Route path="/SignUp">
            <SignUp />
          </Route>
        </Switch>
      </div>
    </Router>
  );
};

export default App;
