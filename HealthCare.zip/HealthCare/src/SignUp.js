import React, { useState } from 'react';
import './SignUp.css';

function SignUp() {
  const [formData, setFormData] = useState({
    name: '',
    password: '',
    email: '',
    dob: '',
    phone: '',
    address: '',
    role: '',
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(formData);
    alert(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Name:
        <input
          type="text"
          name="name"
          placeholder="create user name"
          value={formData.name}
          onChange={handleChange}
        />
      </label>
      <label>
        Password:
        <input
          type="password"
          name="password"
          placeholder="create password"
          value={formData.password}
          onChange={handleChange}
        />
      </label>
      <label>
        Email:
        <input
          type="email"
          name="email"
          placeholder="enter email"
          value={formData.email}
          onChange={handleChange}
        />
      </label>
      <label>
        Date of Birth:
        <input
          type="date"
          name="dob"
          value={formData.dob}
          onChange={handleChange}
        />
      </label>
      <label>
        Phone:
        <input
          type="number"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
        />
      </label>
      <label>
        Address:
        <input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
        />
      </label>
      {/* <label>
        Role:
        <select value={formData.role} onChange={handleChange}>
          <option value="">-- Select a Role--</option>
          <option value="Doctor">Doctor</option>
          <option value="User">User</option>
          <option value="Admin">Admin</option>
        </select>
      </label> */}
      <button type="submit">Submit</button>
    </form>
  );
}

export default SignUp;
