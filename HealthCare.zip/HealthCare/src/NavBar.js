import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css';
const NavBar = () => {
  return (
    <>
      <header className="header">
        <h2>
          {' '}
          <NavLink to="/">MY HEALTH CARE</NavLink>
        </h2>
        <nav className="navbar">
          <NavLink to="/">HOME</NavLink>
          <NavLink to="/doctorsList">DOCTORS</NavLink>
          <NavLink to="/pharmaciesdetails">PHARMACIES</NavLink>
          <NavLink to="/SignUp">SIGN UP</NavLink>
        </nav>
      </header>
    </>
  );
};
export default NavBar;
