import React from 'react';
const Doctors = () => {
  const arrayList = [
    {
      name: 'AMIT KUMAR',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
    {
      name: 'Person2',
      phoneNum: '123456',
      Specialist: 'Dermatology',
      address: 'testone',
    },
  ];

  return (
    <div>
      {arrayList.map((item) => {
        return (
          <div className="card">
            <div className="image">
              {' '}
              <center>
                {' '}
                <h1>{item.name}</h1>
              </center>
            </div>
            <br />
            <div class="title">
              <p> Phone :{item.phoneNum}</p>
            </div>
            <div class="des">
              <p>Specialist:{item.Specialist}</p>
            </div>
            <div class="des">
              <p>Address:{item.address}</p>
              <button>Buy Now</button>
            </div>
          </div>
        );
      })}
    </div>
  );
};
export default Doctors;
